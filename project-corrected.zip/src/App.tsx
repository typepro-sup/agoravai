import React from 'react';
import { motion } from 'framer-motion';
import { Bot, Clock, DollarSign, Rocket, Zap, CheckCircle2, ChevronDown, MessageSquare } from 'lucide-react';

function App() {
  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const faqItems = [
    {
      question: "Como funciona a ferramenta de IA?",
      answer: "Nossa ferramenta utiliza inteligência artificial avançada para criar páginas de vendas otimizadas em questão de minutos. Basta inserir algumas informações básicas sobre seu produto, e a IA fará todo o trabalho pesado."
    },
    {
      question: "A hospedagem é realmente gratuita?",
      answer: "Sim! Oferecemos hospedagem gratuita para todas as páginas criadas com nossa ferramenta, sem custos adicionais."
    },
    {
      question: "Preciso ter conhecimento técnico?",
      answer: "Não! Nossa plataforma foi desenvolvida para ser extremamente intuitiva e fácil de usar, mesmo para quem não tem experiência técnica."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-green-800 text-white">
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <motion.div {...fadeIn} className="text-center">
          <div className="flex justify-center mb-8">
            <Bot size={64} className="text-green-400" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-blue-400">
            Páginas de Vendas com alta conversão feitas por Inteligência Artificial
          </h1>
          <div className="relative w-full max-w-4xl mx-auto my-12 rounded-2xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80"
              alt="AI Sales Page Generator"
              className="w-full object-cover rounded-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-900/80 to-transparent"></div>
          </div>
          <p className="text-xl md:text-2xl mb-8">
            Tenha acesso a essa ferramenta que cria página de vendas em segundos com hospedagem incluída.
          </p>
          <p className="text-green-400 text-2xl md:text-3xl font-bold mb-8">
            Por apenas R$19
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-8 rounded-full text-xl shadow-lg transition-all"
          >
            🔥 QUERO A FERRAMENTA
          </motion.button>
        </motion.div>
      </section>

      {/* Problem Section */}
      <section className="bg-white/10 backdrop-blur-lg py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl font-bold mb-8">ESSA FERRAMENTA É PRA VOCÊ QUE:</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {[
                { icon: <Clock />, text: "Quer criar páginas de vendas de alta conversão em menos de 2 minutos" },
                { icon: <Zap />, text: "Precisa de uma solução rápida e fácil, com templates prontos" },
                { icon: <Bot />, text: "Deseja uma IA que escreve textos persuasivos automaticamente" },
                { icon: <Rocket />, text: "Busca uma plataforma intuitiva, focada 100% em resultados" }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  className="flex items-center gap-4 bg-white/5 p-6 rounded-xl"
                >
                  <div className="text-green-400">{item.icon}</div>
                  <p className="text-left">{item.text}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl font-bold mb-12">Com esta ferramenta, você ganha:</h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { icon: <DollarSign />, title: "Hospedagem grátis" },
                { icon: <Clock />, title: "Tempo para escalar suas ofertas" },
                { icon: <Rocket />, title: "Nova fonte de renda" },
                { icon: <Bot />, title: "Copy de alta conversão" },
                { icon: <Zap />, title: "Páginas ultra rápidas" }
              ].map((benefit, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white/5 p-6 rounded-xl hover:bg-white/10 transition-all"
                >
                  <div className="text-green-400 flex justify-center mb-4">{benefit.icon}</div>
                  <h3 className="text-xl font-semibold">{benefit.title}</h3>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-white/5 py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl font-bold mb-12">Depoimentos de pessoas que transformaram suas vidas!</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  text: "Eu sempre achei que criar uma página de vendas era complicado e demorado, mas essa ferramenta mudou tudo! Em apenas 2 minutos, minha página estava pronta, linda e otimizada para conversão.",
                  author: "Ana S., Empreendedora Digital"
                },
                {
                  text: "Eu já tinha tentado várias plataformas para criar páginas de vendas, mas sempre levava horas ajustando detalhes. Com essa inteligência artificial, criei minha página em 2 minutos e comecei a vender no mesmo dia!",
                  author: "Lucas M., Lançador de Infoprodutos"
                }
              ].map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="bg-white/5 p-8 rounded-xl"
                >
                  <MessageSquare className="text-green-400 mb-4" />
                  <p className="italic mb-4">{testimonial.text}</p>
                  <p className="text-green-400 font-semibold">{testimonial.author}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold mb-8">🔥 QUERO ESSA FERRAMENTA DE IA!</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
              {[
                "Hospedagem gratuita incluída",
                "Suporte técnico 24/7",
                "Templates profissionais",
                "Atualizações constantes",
                "Garantia de 30 dias"
              ].map((benefit, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle2 className="text-green-400" />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-green-500 hover:bg-green-600 text-white font-bold py-4 px-8 rounded-full text-xl shadow-lg transition-all"
            >
              🔥 QUERO COMEÇAR AGORA
            </motion.button>
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-white/5 py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Perguntas Frequentes</h2>
          <div className="max-w-3xl mx-auto space-y-4">
            {faqItems.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 rounded-lg p-6"
              >
                <details className="group">
                  <summary className="flex justify-between items-center cursor-pointer">
                    <span className="font-semibold">{item.question}</span>
                    <ChevronDown className="transform group-open:rotate-180 transition-transform" />
                  </summary>
                  <p className="mt-4 text-gray-300">{item.answer}</p>
                </details>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;